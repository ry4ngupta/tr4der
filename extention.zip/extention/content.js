console.log('[tr4der] Content script loaded. Path:', window.location.pathname);
// ==UserScript==
// @name         tr4der AI TradingView Popup
// @namespace    http://tr4der.app/
// @version      1.0
// @description  Injects a professional AI trading popup on TradingView charts
// ==/UserScript==

const GEMINI_API_KEY = "AIzaSyD-Js_D2h32IvqhrE3bjqo2t2aVuStSAJY";
const DASHBOARD_URL = "https://tr4der.app/dashboard";

function createStyles() {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes tr4derFadeIn {
      from { opacity: 0; transform: translateY(30px) scale(0.95); }
      to { opacity: 1; transform: none; }
    }
    #tr4der-widget {
      position: fixed;
      bottom: 32px;
      right: 32px;
      z-index: 99999;
      background: linear-gradient(135deg, #181c24 60%, #232a36 100%);
      color: #f3f4f6;
      border-radius: 16px;
      box-shadow: 0 8px 32px 0 rgba(0,0,0,0.25);
      min-width: 270px;
      max-width: 340px;
      padding: 20px 22px 18px 22px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      animation: tr4derFadeIn 0.7s cubic-bezier(.4,0,.2,1);
      transition: opacity 0.3s, transform 0.3s;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    #tr4der-widget h3 {
      font-size: 1.2rem;
      font-weight: 700;
      margin-bottom: 6px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    #tr4der-widget .market {
      font-weight: 600;
      color: #a5b4fc;
      margin-bottom: 4px;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    #tr4der-widget .recommendation {
      font-size: 1.08rem;
      font-weight: 500;
      margin: 8px 0 6px 0;
      display: flex;
      align-items: center;
      gap: 8px;
      opacity: 0;
      animation: tr4derFadeIn 1.2s 0.2s forwards;
    }
    #tr4der-widget .explanation {
      font-size: 0.98rem;
      color: #cbd5e1;
      margin-bottom: 8px;
      margin-top: 2px;
    }
    #tr4der-widget .dashboard-btn {
      background: linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%);
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 8px 18px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      margin-top: 8px;
      box-shadow: 0 2px 8px 0 rgba(99,102,241,0.15);
      transition: background 0.2s, transform 0.2s;
    }
    #tr4der-widget .dashboard-btn:hover {
      background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
      transform: scale(1.04);
    }
    #tr4der-widget .close-btn {
      position: absolute;
      top: 10px;
      right: 12px;
      background: none;
      border: none;
      color: #a5b4fc;
      font-size: 1.2rem;
      cursor: pointer;
      transition: color 0.18s;
    }
    #tr4der-widget .close-btn:hover {
      color: #f87171;
    }
    #tr4der-widget .spinner {
      border: 3px solid #232a36;
      border-top: 3px solid #6366f1;
      border-radius: 50%;
      width: 24px;
      height: 24px;
      animation: spin 1s linear infinite;
      margin-right: 8px;
      display: inline-block;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);
}

function createWidget() {
  if (document.getElementById('tr4der-widget')) return;
  const widget = document.createElement('div');
  widget.id = 'tr4der-widget';
  widget.innerHTML = `
    <button class="close-btn" title="Close">✖️</button>
    <button class="min-btn" title="Minimize" style="position:absolute;top:10px;right:38px;background:none;border:none;color:#a5b4fc;font-size:1.2rem;cursor:pointer;transition:color 0.18s;">_</button>
    <h3>tr4der <span>💡</span></h3>
    <div class="market">Market: <span id="tr4der-market">...</span></div>
    <div class="best-move" id="tr4der-best-move" style="font-size:1.2rem;font-weight:700;margin:8px 0 4px 0;color:#a5b4fc;"></div>
    <div class="recommendation" id="tr4der-recommendation"><span id="tr4der-recIcon">🤖</span> <span id="tr4der-recText">Loading...</span></div>
    <div class="explanation" id="tr4der-explanation"></div>
    <button class="dashboard-btn">Go to Dashboard</button>
  `;
  document.body.appendChild(widget);
  widget.querySelector('.close-btn').onclick = () => {
    widget.style.opacity = '0';
    widget.style.transform = 'translateY(30px) scale(0.95)';
    setTimeout(() => widget.remove(), 300);
  };
  widget.querySelector('.dashboard-btn').onclick = () => {
    window.open(DASHBOARD_URL, '_blank');
  };
  // Minimize/restore logic
  const minBtn = widget.querySelector('.min-btn');
  minBtn.onclick = () => {
    if (widget.classList.contains('minimized')) {
      widget.classList.remove('minimized');
      widget.style.height = '';
      widget.style.width = '';
      widget.style.overflow = '';
      Array.from(widget.children).forEach(el => { if (el !== minBtn && el !== widget.querySelector('.close-btn')) el.style.display = ''; });
      minBtn.textContent = '_';
    } else {
      widget.classList.add('minimized');
      widget.style.height = '38px';
      widget.style.width = '180px';
      widget.style.overflow = 'hidden';
      Array.from(widget.children).forEach(el => { if (el !== minBtn && el !== widget.querySelector('.close-btn')) el.style.display = 'none'; });
      minBtn.textContent = '▢';
    }
  };
}

function setWidgetLoading() {
  const recText = document.getElementById('tr4der-recText');
  if (recText) recText.innerHTML = '<span class="spinner"></span> Loading...';
  const explanation = document.getElementById('tr4der-explanation');
  if (explanation) explanation.textContent = '';
}

function setWidgetError(errorMsg) {
  const recText = document.getElementById('tr4der-recText');
  if (recText) recText.innerHTML = '<span style="color:#f87171;">Error</span>';
  const explanation = document.getElementById('tr4der-explanation');
  if (explanation) explanation.textContent = errorMsg;
}

function updateWidget(market, aiResult) {
  document.getElementById('tr4der-market').textContent = market || '-';
  const recIcon = document.getElementById('tr4der-recIcon');
  const recText = document.getElementById('tr4der-recText');
  const explanation = document.getElementById('tr4der-explanation');
  const bestMove = document.getElementById('tr4der-best-move');
  let icon = '🤖';
  if (aiResult.recommendation === 'Buy' || aiResult.recommendation === 'Long') icon = '🟢💹';
  else if (aiResult.recommendation === 'Sell' || aiResult.recommendation === 'Short') icon = '🔴📉';
  else if (aiResult.recommendation === 'Hold' || aiResult.recommendation === 'Neutral') icon = '🟡🤚';
  recIcon.textContent = icon;
  recText.innerHTML = `<b>Recommendation:</b> ${aiResult.recommendation || '-'}<br/>
    <b>Confidence:</b> ${aiResult.confidence || '-'}<br/>
    <b>Entry Zone:</b> ${aiResult.entry_zone || '-'}<br/>
    <b>Exit Zone:</b> ${aiResult.exit_zone || '-'}<br/>
    <b>Stop Loss:</b> ${aiResult.stop_loss || '-'}<br/>`;
  explanation.textContent = aiResult.explanation || '';
  // Show best move with extra info
  let moveText = '';
  if (aiResult.best_move) {
    moveText = aiResult.best_move;
  } else if (aiResult.recommendation) {
    moveText = `Best Move: ${aiResult.recommendation}`;
    if (aiResult.amount) moveText += ` | Amount: ${aiResult.amount}`;
    if (aiResult.hold_time) moveText += ` | Hold for: ${aiResult.hold_time}`;
  }
  bestMove.textContent = moveText;
}

function getCurrentMarket() {
  // Try to get symbol from TradingView's new DOM structure
  const symbolBtn = document.querySelector('button[aria-label="Change symbol"]');
  if (symbolBtn) return symbolBtn.textContent.trim();
  // Try to get symbol from TradingView's symbol header (legacy)
  const el = document.querySelector('.tv-symbol-header__first-line .tv-symbol-header__symbol');
  if (el) return el.textContent.trim();
  // Try to get symbol from the URL (if present)
  const url = window.location.href;
  const match = url.match(/[?&]symbol=([A-Z0-9:_-]+)/i);
  if (match) return match[1];
  // fallback: try data-symbol attribute
  const chart = document.querySelector('[data-symbol]');
  if (chart) return chart.getAttribute('data-symbol');
  return null;
}

async function fetchAIRecommendation(market) {
  // Use Gemini API (latest supported vision model)
  const prompt = `Act as an advanced trading AI with expertise in technical analysis, algorithmic trading, and market sentiment evaluation. Analyze the current market conditions for ${market} and EXPLICITLY state the best move (buy, hold, or sell). For buy/sell, specify the amount (e.g. 10 shares, 0.5 BTC, etc.) and for hold, specify how long to hold for. Provide a clear, concise summary in a 'best_move' field, and also include: recommendation, confidence, entry_zone, exit_zone, stop_loss, explanation, amount, hold_time. Respond with only a valid JSON object, no extra text, no markdown, no explanation, no code block, just the JSON: { "best_move": "...", "recommendation": "...", "confidence": "...", "entry_zone": "...", "exit_zone": "...", "stop_loss": "...", "explanation": "...", "amount": "...", "hold_time": "..." }`;
  try {
    console.log('[tr4der] Sending Gemini API request for market:', market);
    const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + GEMINI_API_KEY, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });
    const data = await res.json();
    console.log('[tr4der] Gemini API response:', data);
    let text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    let aiResult;
    try {
      aiResult = JSON.parse(text.match(/{[\s\S]*}/)?.[0] || '{}');
    } catch (err) {
      console.error('[tr4der] Failed to parse Gemini response as JSON:', text, err);
      setWidgetError('AI could not parse a valid response.');
      return { recommendation: 'Hold', confidence: '-', entry_zone: '-', exit_zone: '-', stop_loss: '-', explanation: 'AI could not parse a valid response.' };
    }
    if (!aiResult.recommendation) {
      setWidgetError('No recommendation received from AI.');
    }
    return aiResult;
  } catch (e) {
    console.error('[tr4der] Error contacting Gemini API:', e);
    setWidgetError('Error contacting Gemini API.');
    return { recommendation: 'Hold', confidence: '-', entry_zone: '-', exit_zone: '-', stop_loss: '-', explanation: 'Error contacting Gemini API.' };
  }
}

async function main() {
  createStyles();
  createWidget();
  setWidgetLoading();
  let lastMarket = null;
  async function update() {
    const market = getCurrentMarket();
    if (!market) return;
    if (market !== lastMarket) setWidgetLoading();
    lastMarket = market;
    const aiResult = await fetchAIRecommendation(market);
    updateWidget(market, aiResult);
  }
  // Initial update
  await update();
  // Observe for market changes
  setInterval(update, 15000); // update every 15s
  // Optionally, use MutationObserver for more reactivity
}

// Only inject on chart pages
if (window.location.pathname.startsWith('/chart/')) {
  main();
} 