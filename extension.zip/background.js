// Background script for tr4der extension
// Currently not used, but required by manifest.json 